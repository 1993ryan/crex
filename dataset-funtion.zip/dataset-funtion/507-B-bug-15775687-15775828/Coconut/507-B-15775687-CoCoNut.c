#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(int argc, char *argv[])
{
    int r , x1 ,y1 ,x2,y2;
    scanf("%d %d %d %d %d",&r,&x1,&y1,&x2,&y2);
    double distance =sqrt(pow((x2-x1),2)+pow((y2-y1),2));
    int steps = ceil( distance /(2*r ) ) ;
    printf("%d",steps);
    return 0;
}
